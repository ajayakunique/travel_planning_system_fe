import React from 'react'
import { Route, Routes } from 'react-router-dom'
import UserLogin from '../User/Userlogin/UserLogin'
import UserSignup from '../User/UserSignup/UserSignup'
import UserForgotPassword from '../User/UserForgotPassword/UserForgotPassword'
import UserResetPassword from '../User/UserResetPassword/UserResetPassword'
import TripHome from '../User/TripHome/TripHome'
import Navbar from '../Common/Navbar/Navbar'
import TripPeople from '../User/TripPeople/TripPeople'
import TravelWith from '../User/TravelWith/TravelWith'
import Budget from '../User/Budget.css/Budget'
import TravelMode from '../User/TravelMode/TravelMode'
import RecommendedTrips from '../User/RecommendedTrip/RecommendedTrips'
import TripDetails from '../User/TripDetails/TripDetails'
import StayOptions from '../User/StayOptions/StayOptions'
import ProfilePage from '../User/ProfilePage/ProfilePage'
import MyTrips from '../User/MyTrips/MyTrips'
import TripDates from '../User/TripDates/TripDates'

export default function Routercom() {
  return (
    <Routes>
      <Route path='/' element={<UserLogin />} />
      <Route path='/usersignup' element={<UserSignup />} />
      <Route path='/userforgotpassword' element={<UserForgotPassword />} />
      <Route path='/userresetpassword' element={<UserResetPassword />} />
      <Route element={<Navbar />}>
        <Route path="/triphome" element={<TripHome />} />
        <Route path='/trippeople' element={<TripPeople/>}/>
        <Route path='/travelwith' element={<TravelWith/>}/>
        <Route path='/budget' element={<Budget/>}/>
        <Route path='/tripdates' element={<TripDates/>}/>
        <Route path='/travelmode' element={<TravelMode/>}/>
        <Route path='/recommendedtrip' element={<RecommendedTrips/>}/>
        <Route path='/tripdetails' element={<TripDetails/>}/>
        <Route path="/stayoptions" element={<StayOptions/>}/>
        <Route path="/profilepage" element={<ProfilePage/>}/>
        <Route path="/mytrips" element={<MyTrips/>}/>
      </Route>

    </Routes>
  )
}
