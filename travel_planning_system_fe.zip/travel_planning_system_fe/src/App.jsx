import React from 'react'
import "./App.css"
import { BrowserRouter } from 'react-router-dom'
import Routercom from './Routercom/Routercom'

export default function App() {
  return (
    <div>
      <BrowserRouter>
      <Routercom/>
      </BrowserRouter>
    </div>
  )
}