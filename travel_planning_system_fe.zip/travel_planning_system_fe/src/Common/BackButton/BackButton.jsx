import React from 'react'
import "./BackButton.css"
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

export default function BackButton({onclick}) {
  return (
    <>
         <button className="common-back-btn" onClick={onclick}>
            <ArrowBackIcon/> Back
          </button>
    </>
  )
}
