import React from 'react'
import "./Navbar.css"
import { Outlet, useNavigate } from 'react-router-dom'
import { FiHome, FiMapPin, FiUser, FiLogOut } from "react-icons/fi";


export default function Navbar() {
  const navigate=useNavigate()
  return (
    <>
      {/* NAVBAR */}
      <div className="trip-nav">
        <div className="trip-logo">
          <div className="trip-logo-icon">✈</div>
          <div className="trip-logo-text">TripAI</div>
        </div>

        <div className="trip-nav-links">
          <div className="nav-item " onClick={()=>navigate('/triphome')}><FiHome /> Home</div>
          <div className="nav-item"onClick={()=>navigate('/mytrips')} ><FiMapPin /> My Trips</div>
          <div className="nav-item"onClick={()=>navigate('/profilepage')}><FiUser /> Profile</div>
          <div className="nav-item"onClick={()=>navigate('/')}><FiLogOut /> Logout</div>
        </div>
      </div>
      <Outlet/>
    </>
  )
}
