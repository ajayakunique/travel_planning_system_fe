import "./TripLoading.css";

export default function TripLoading() {
  return (
    <div className="tl-page">
      <div className="tl-card">

        <div className="tl-loader">
          <div className="tl-plane">✈</div>
        </div>

        <div className="tl-text">
          Analyzing your mood & planning your perfect trip...
        </div>

        <div className="tl-dots">
          <span></span>
          <span></span>
          <span></span>
        </div>

      </div>
    </div>
  );
}
