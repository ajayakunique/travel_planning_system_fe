import React, { useState } from 'react'
import "./UserLogin.css"
import user from "../../assets/user.svg"
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'


export default function UserLogin() {
  const loginuserdata = [{
    label: 'Email',
    name: 'email',
    type: 'text',
    placeholder: 'Email Address',
    autocomplete: 'email'
  }, {
    label: 'Password',
    name: 'password',
    type: 'password',
    placeholder: 'Password',
    autocomplete: 'password'
  }
  ]

  const [userlogindata, setUserlogindata] = useState({})

  const userloginchange = (e) => {
    setUserlogindata({ ...userlogindata, [e.target.name]: e.target.value })
  }

  const userlogincheck =async (e) => {
    e.preventDefault()
    try{
      const response=await axios.post("http://127.0.0.1:8000/login",userlogindata)
      console.log(response);
      
      if (response.data.message=='Login successful'){
        alert(response.data.message)
        localStorage.setItem('email',userlogindata.email)
        navigate('/triphome')
      }
      else{
        alert('Login Failed')
      }
    }
    catch(error){
      console.log(error)
    }
  }

  const navigate = useNavigate()

  return (
    <div className='user-login-main'>
      <div className="user-login-left-side">
        <img className='user-login-img' src={user} alt="" />
      </div>
      <form className="user-login-right-side" onSubmit={userlogincheck} method='post'>
        <div className="user-login-card">
          <div className="user-login-inner-card-container">
            <div className="user-login-head-text">
              Hello !
            </div>
            <div className="user-login-sub-text">
              Login to Get Started
            </div>
            {loginuserdata.map((value) => (
              <div key={value.name} className='user-login-input-div'>
                <label className='user-login-label-text' htmlFor="">{value.label} :</label>
                <input className='user-login-input' onChange={userloginchange} name={value.name} placeholder={value.placeholder} type={value.type} autoComplete={value.autocomplete} required />
              </div>
            ))}
            <div className='user-login-forgot-text' onClick={() => navigate('/userforgotpassword',userlogindata.email)}>forgot password</div>
            <button className='user-login-btn' onClick={userlogincheck}>Login</button>
            <div className='user-login-Sign-up-text'>
              Doesn't have an account yet? <Link to={'/usersignup'}>Signup</Link>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}

