import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import "./ProfilePage.css";
import { FiUser, FiMap } from "react-icons/fi";
import axios from "axios";

export default function ProfilePage() {
  const navigate = useNavigate();

  const [profile, setProfile] = useState({
    trip_count: 0,
    last_trip_place: ""
  });

  const email = localStorage.getItem("email");

  const getProfile = async () => {
    try {
      const response = await axios.get(`http://127.0.0.1:8000/profile/${email}`
      );
      setProfile(response.data);
      console.log(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getProfile();
  }, []);

  return (
    <div className="profile-page">
      <div className="profile-wrapper">
        <div className="profile-card">

          <div className="profile-avatar">
            <FiUser />
          </div>

          <div className="profile-name">{profile.username}</div>

          <div className="profile-box">
            <div className="profile-row">
              <div className="row-left">
                <FiMap /> Trips Planned
              </div>
              <div className="row-value">
                {profile.trip_count}
              </div>
            </div>
          </div>

          <div className="profile-box">
            <div className="profile-row">
              <div className="row-left">
                🧭 Last Planned Trip
              </div>
              <div className="row-value">
                {profile.last_trip_place || "No trips yet"}
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate("/mytrips")}
            className="profile-btn"
          >
            Back to My Trips
          </button>

        </div>
      </div>
    </div>
  );
}