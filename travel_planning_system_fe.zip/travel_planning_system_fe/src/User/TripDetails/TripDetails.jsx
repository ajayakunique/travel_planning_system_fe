import { useLocation, useNavigate, useParams } from "react-router-dom";
import "./TripDetails.css";
import axios from "axios";
import { useState } from "react";
import TripLoading from "../../Common/TripLoading/TripLoading";

export default function TripDetails() {

  const [loading, setLoading] = useState(false);

  const loc = useLocation()
  console.log(loc.state);
  const trip = loc.state.details
  const navigate = useNavigate()


  const HandleClick = async () => {
    try {
      setLoading(true);
      const response = await axios.post("http://127.0.0.1:8000/stays", {
        place: loc.state.details.title,
        budget: Number(loc.state.budget)
      })
      console.log(response.data)
      navigate("/stayoptions", {
        state:
        {
          hotel: response.data,
          members: loc.state.members,
          place: loc.state.details.title,
          budget: Number(loc.state.budget),
          people_type: loc.state.people_type,
          transport: loc.state.transport,
          image:loc.state.details.image,
          date:loc.state.date
        }
      })
    }
    catch (error) {
      console.log(error);
      alert("Server error");
    }
    finally {
      setLoading(false);
    }
  }
  if (loading) {
    return <TripLoading />;
  }

  return (
    <div className="td-page">

      <div className="td-wrapper">

        <div className="td-img">
          <img src={trip.image} alt="" />
        </div>

        <div className="td-info">

          <div className="td-title">{trip.title}</div>

          <div className="td-section-title">INTERESTING FACT</div>
          <div className="td-text">{trip.fact}</div>

          <div className="td-section-title">WHY THIS TRIP SUITS YOU</div>

          <div className="td-list">
            {trip.points.map((p, i) => (
              <div key={i} className="td-point">
                ✔ {p}
              </div>
            ))}
          </div>

          <div className="td-btn" onClick={HandleClick}>View Stay Options</div>

        </div>

      </div>

    </div>
  );
}
