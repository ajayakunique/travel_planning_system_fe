import { FiMapPin, FiFilter } from "react-icons/fi";
import "./RecommendedTrips.css";
import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";



export default function RecommendedTrips() {

  const rectrip = [
    {
      id: 1,
      title: "Manali, Himachal Pradesh",
      distance: "540 km away",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",
      tags: ["Budget Friendly", "Adventure"],
      fact: "Manali sits at 2,050 meters above sea level and offers stunning Himalayan views.",
      points: [
        "Perfect for trekking and mountain adventures",
        "Affordable stays including cozy homestays",
        "Ideal for group trips and nature lovers"
      ]
    },
    {
      id: 2,
      title: "Goa Beaches",
      distance: "590 km away",
      image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
      tags: ["Budget Friendly", "Relaxing"],
      fact: "Goa is famous for its golden beaches and vibrant nightlife.",
      points: [
        "Relax by scenic beaches and sunsets",
        "Enjoy water sports and beach shacks",
        "Perfect mix of fun and relaxation"
      ]
    },
    {
      id: 3,
      title: "Coorg, Karnataka",
      distance: "265 km away",
      image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
      tags: ["Budget Friendly", "Nature"],
      fact: "Coorg is known as the Scotland of India for its misty hills and coffee plantations.",
      points: [
        "Peaceful escape into lush greenery",
        "Visit coffee estates and waterfalls",
        "Great for nature photography"
      ]
    },
    {
      id: 4,
      title: "Jaipur, Rajasthan",
      distance: "280 km away",
      image: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66",
      tags: ["Heritage"],
      fact: "Jaipur is called the Pink City due to its iconic terracotta-colored buildings.",
      points: [
        "Explore forts and royal palaces",
        "Experience rich Rajasthani culture",
        "Perfect for history lovers"
      ]
    },
    {
      id: 5,
      title: "Mumbai City",
      distance: "320 km away",
      image: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66",
      tags: ["Urban"],
      fact: "Mumbai is India's financial capital and home to Bollywood.",
      points: [
        "Experience vibrant city life",
        "Visit iconic Gateway of India",
        "Perfect for food and nightlife"
      ]
    },
    {
      id: 6,
      title: "Ooty Hills",
      distance: "210 km away",
      image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
      tags: ["Budget Friendly", "Adventure"],
      fact: "Ooty is famous for its cool climate and scenic tea plantations.",
      points: [
        "Relax in pleasant hill weather",
        "Ride the famous Nilgiri mountain train",
        "Great for peaceful getaways"
      ]
    },
    {
      id: 7,
      title: "Kerala Backwaters",
      distance: "430 km away",
      image: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944",
      tags: ["Relaxing"],
      fact: "Kerala backwaters are a network of tranquil lagoons and canals.",
      points: [
        "Enjoy houseboat stays and scenic cruises",
        "Experience serene village life",
        "Perfect for stress-free relaxation"
      ]
    },
    {
      id: 8,
      title: "Hampi Ruins",
      distance: "350 km away",
      image: "https://images.unsplash.com/photo-1587474260584-136574528ed5",
      tags: ["Budget Friendly", "Nature"],
      fact: "Hampi is a UNESCO World Heritage site filled with ancient ruins.",
      points: [
        "Explore historic temples and monuments",
        "Unique landscapes and boulder hills",
        "Great for culture and photography lovers"
      ]
    }
  ];
  const loc = useLocation()
  var rectrips = loc.state.data.places
  console.log(loc.state);
  console.log(rectrips);

  const navigate = useNavigate()



  return (

    <div className="rt-page">

      <div className="rt-header">
        <div className="rt-title">Recommended Trips for You</div>
      </div>

      <div className="rt-wrapper">
        {rectrips.map(trip => (
          <div key={trip.id} className="rt-card" onClick={() => (navigate('/tripdetails', {
            state: {
              details: trip,
              budget: loc.state.budget,
              members: loc.state.members,
              people_type: loc.state.people_type,
              transport: loc.state.transport,
              date:loc.state.date
            }
          }))}>

            <div className="rt-img-box">
              <img src={trip.image} alt="" />


              <div className="rt-tags">
                {trip.tags.map((t, i) => (
                  <div key={i} className="tag">{t}</div>
                ))}
              </div>
            </div>

            <div className="rt-content">
              <div className="rt-place">{trip.title}</div>

              <div className="rt-distance">
                <FiMapPin /> {trip.distance}
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
