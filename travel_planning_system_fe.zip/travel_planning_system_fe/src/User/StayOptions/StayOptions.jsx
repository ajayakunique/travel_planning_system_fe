import { useLocation, useNavigate } from "react-router-dom";
import "./StayOptions.css";
import axios from "axios";



const stay = [
  {
    id: 1,
    name: "Mountain View Resort",
    rating: 4.5,
    price: 2500,
    image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
  },
  {
    id: 2,
    name: "Himalayan Retreat",
    rating: 4.7,
    price: 3200,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
  },
  {
    id: 3,
    name: "Pine Valley Hotel",
    rating: 4.2,
    price: 1800,
    image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
  },
  {
    id: 4,
    name: "Green Hill Cottage",
    rating: 4.6,
    price: 2100,
    image: "https://images.unsplash.com/photo-1445019980597-93fa8acb246c"
  },
  {
    id: 5,
    name: "Nature Stay Lodge",
    rating: 4.3,
    price: 1950,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
  }
];

export default function StayOptions() {

  const loc = useLocation()
  console.log(loc.state);
  const stays = loc.state.hotel.stays
  const navigate = useNavigate()

  const SaveTrip = async () => {
    try{
    const response = await axios.post("http://127.0.0.1:8000/save-trip", {
      user_email: localStorage.getItem('email'),
      place_name:loc.state.place,
      people_type:loc.state.people_type,
      members: loc.state.members,
      budget: Number(loc.state.budget),
      transport: loc.state.transport,
      image:loc.state.image,
      date:loc.state.date
    })
    if(response.data.message=="Trip saved"){
      navigate("/mytrips")
    }
    else{
      alert("something wrong")
    }
  }
  catch(error){
    console.log(error);
  }
}

  return (
    <div className="stay-page">

      <div className="stay-wrapper">
        <div className="stay-title">Stay Options</div>

        <div className="stay-grid">
          {stays.map((stay) => (
            <div key={stay.id} className="stay-card">

              <div className="stay-image-box">
                <img src={stay.image} alt="" />
                <div className="badge">Budget Match</div>
              </div>

              <div className="stay-content">
                <div className="stay-name">{stay.name}</div>

                <div className="stay-bottom">
                  <div className="rating">⭐ {stay.rating}</div>

                  <div className="price">
                    {stay.price}
                    <span>per night</span>
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>

        <button onClick={SaveTrip} className="save-btn">Save Trip</button>
      </div>
    </div>
  )
}