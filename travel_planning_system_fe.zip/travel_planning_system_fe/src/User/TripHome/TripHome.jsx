import { useNavigate } from "react-router-dom";
import "./TripHome.css";
import { useState } from "react";

export default function TripHome() {

  const [moodtext, setMoodtext] = useState()
  console.log(moodtext);
  const navigate = useNavigate()
  const Homeclick = () => {
    if (moodtext == null || moodtext.mood_text ==" ") {
      window.alert("Write Something")
    }
    else {
      navigate('/trippeople',{state:moodtext.mood_text})
    }
  }

  return (
    <div className="trip-page">

      <div className="trip-body">

        <div className="trip-card">
          <div className="trip-title">Plan Your Perfect Trip</div>

          <textarea onChange={(e) => (setMoodtext({ mood_text: e.target.value }))}
            className="trip-input"
            placeholder="How are you feeling & what kind of trip do you want?"
            required />

          <div className="trip-hint">
            Tell us your mood to personalize your journey.
          </div>

          <button className="trip-btn" onClick={Homeclick}>Next</button>
        </div>

        <div className="trip-image-box">
          <img
            src="https://images.unsplash.com/photo-1501785888041-af3ef285b470"
            alt="mountain"
          />
        </div>

      </div>

    </div>
  );
}
