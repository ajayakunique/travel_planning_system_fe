import { useState } from "react";
import "./TravelMode.css";
import BackButton from "../../Common/BackButton/BackButton";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import TripLoading from "../../Common/TripLoading/TripLoading";

function TravelMode() {
  const [selected, setSelected] = useState("");
  const [loading, setLoading] = useState(false);

  const modes = [
    { name: "Car", icon: "🚗" },
    { name: "Bike", icon: "🏍️" },
    { name: "Bus", icon: "🚌" },
    { name: "Train", icon: "🚆" },
    { name: "Flight", icon: "✈️" },
  ];

  const loc = useLocation();
  const navigate = useNavigate();

  const Generatetrip = async () => {
    if (!selected.trim()) {
      alert("Select type");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post("http://127.0.0.1:8000/suggest", {
        mood_text: loc.state.mood_text,
        people_type: loc.state.people_type,
        members: loc.state.members,
        budget: loc.state.budget,
        transport: selected
      });

      console.log(response.data);
      navigate("/recommendedtrip", {
        state:
        {
          data: response.data,
          budget: loc.state.budget,
          members: loc.state.members,
          people_type: loc.state.people_type,
          date:loc.state.date,
          transport: selected
        }
      });
    } catch (err) {
      console.error(err);
      alert("Server error");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <TripLoading />;
  }

  return (
    <div className="mode-page">
      <div className="mode-card">
        <BackButton onclick={() => navigate("/budget")} />
        <h2 className="mode-title">How will you travel?</h2>

        <div className="mode-options">
          {modes.map((mode) => (
            <div
              key={mode.name}
              className={`mode-option ${selected === mode.name ? "mode-active" : ""
                }`}
              onClick={() => setSelected(mode.name)}
            >
              <div className="mode-icon">{mode.icon}</div>
              <div className="mode-label">{mode.name}</div>
            </div>
          ))}
        </div>

        <button className="mode-btn" onClick={Generatetrip}>
          Generate My Trip
        </button>
      </div>
    </div>
  );
}

export default TravelMode;