import { useNavigate } from "react-router-dom";
import "./MyTrips.css";
import {
    FiHome,
    FiMapPin,
    FiUser,
    FiLogOut,
    FiCalendar,
    FiTrendingUp,
    FiUsers,
} from "react-icons/fi";
import axios from "axios";
import { useEffect, useState } from "react";

export default function MyTrips() {

    const trip= [
        {
            place: "Manali, Himachal Pradesh",
            date: "17 Feb 2026",
            budget: "₹45,000",
            group: "Family",
            image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
        },
        {
            place: "Goa, India",
            date: "05 Mar 2026",
            budget: "₹28,000",
            group: "Friends",
            image:
                "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
        },
    ];
    const [trips, setTrips]=useState([])
    const navigate = useNavigate()

    const Gettrips = async () => {
        try {
            const response = await axios.get(`http://127.0.0.1:8000/saved-trips/${localStorage.getItem('email')}`)
            setTrips(response.data);
            console.log(response.data);
            
        }
        catch (error) {
            console.log(error);
        }
    }
    useEffect(
        () => {
            Gettrips()
        }, []
    )

    return (
        <div className="trips-page">

            <div className="trips-content">
                <h1 className="trips-title">My Trips</h1>

                <div className="trips-card-container">
                    {trips.map((trip, index) => (
                        <div className="trips-card" key={index}>
                            <img src={trip.image} alt={trip.place} />

                            <div className="trips-info">
                                <h3>{trip.place_name}</h3>

                                <div className="trips-details">
                                    <span><FiCalendar /> {trip.date}</span> 
                                    <span><FiTrendingUp />₹{trip.budget}</span>
                                </div>

                                <div className="trips-group">
                                    <FiUsers /> {trip.people_type}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="plan-btn-container">
                    <button onClick={() => navigate('/triphome')} className="plan-btn">
                        Plan New Trip
                    </button>
                </div>

            </div>
        </div>
    );
}
