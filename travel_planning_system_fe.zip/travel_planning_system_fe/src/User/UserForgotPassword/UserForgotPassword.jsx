import React, { useState } from 'react'
import "./UserForgotPassword.css"
import user from "../../assets/user.svg"
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

export default function UserForgotPassword() {
    const signupforgotdata = [
        {
            label: 'Email',
            name: 'email',
            type: 'text',
            placeholder: 'Email Address',
            autocomplete: 'email'
        }
    ]

    const [userforgotdata, setUserforgotdata] = useState({})

    const userforgotchange = (e) => {
        setUserforgotdata({ ...userforgotdata, [e.target.name]: e.target.value })
    }

    const userforgotcheck = async (e) => {
        try {
            e.preventDefault()
            const response = await axios.post("http://127.0.0.1:8000/forgot_password", userforgotdata)
            console.log(response);

            if (response.data.message == "Access Successful") {
                window.alert('Accessed')
                navigate('/userresetpassword', { state: { email: userforgotdata.email } })
            }

        }
        catch (error) {
            window.alert(error)
        }
    }

    const navigate = useNavigate()

    return (
        <div className='user-forgot-main'>
            <div className="user-forgot-left-side">
                <img className='user-forgot-img' src={user} alt="" />
            </div>
            <form className="user-forgot-right-side" onSubmit={userforgotcheck} method='post'>
                <div className="user-forgot-card">
                    <div className="user-forgot-inner-card-container">
                        <div className="user-forgot-head-text">
                            Forgot Password ?
                        </div>
                        <div className="user-forgot-sub-text">
                            provide the email address associated with your account to recover your password
                        </div>
                        {signupforgotdata.map((value) => (
                            <div key={value.name} className='user-forgot-input-div'>
                                <label className='user-forgot-label-text' htmlFor="">{value.label} :</label>
                                <input className='user-forgot-input' onChange={userforgotchange} name={value.name} placeholder={value.placeholder} type={value.type} autoComplete={value.autocomplete} required />
                            </div>
                        ))}
                        <button className='user-forgot-btn' onClick={userforgotcheck}>Submit</button>
                        <button class="back-btn" onClick={()=>navigate("/")}>
                            <span>←</span> Back
                        </button>
                    </div>
                </div>
            </form>
        </div>
    )
}
