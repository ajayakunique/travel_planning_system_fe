import { useState } from "react";
import "./Budget.css";
import BackButton from "../../Common/BackButton/BackButton";
import { useLocation, useNavigate } from "react-router-dom";

function Budget() {
  const [budget, setBudget] = useState();
  const loc = useLocation()
  console.log(loc.state);

  const navigate = useNavigate()
  return (
    <div className="budget-page">
      <div className="budget-card">

        <BackButton onclick={() => navigate('/travelwith')} />

        <h2 className="budget-title">Enter your travel budget</h2>

        <div className="budget-input-box">
          <span className="budget-rupee">₹</span>
          <input
            type="number"
            placeholder="25000"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
          />
        </div>

        <p className="budget-hint">
          AI will suggest trips within your budget.
        </p>

        <button className="budget-next-btn" onClick={() => {
          if (budget == "" || budget == null) {
            alert('Enter Your Budget')
          }
          else {
            navigate('/tripdates', {
              state:
              {
                mood_text: loc.state.mood_text,
                members: loc.state.members,
                people_type: loc.state.people_type,
                budget: budget
              }
            })
          }
        }}
        >
          Next
        </button>

      </div>
    </div>
  );
}

export default Budget;
