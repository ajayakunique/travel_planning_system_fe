import React, { useState } from 'react'
import "./UserSignup.css"
import user from "../../assets/user.svg"
import { useNavigate } from 'react-router-dom'
import axios from 'axios'


export default function UserSignup() {
    const signupuserdata = [
        {
            label: 'Name',
            name: 'username',
            type: 'text',
            placeholder: 'Enter Your Name',
            autocomplete: 'name'
        },
        {
            label: 'Email',
            name: 'email',
            type: 'text',
            placeholder: 'Email Address',
            autocomplete: 'email'
        }, {
            label: 'Create Password',
            name: 'password',
            type: 'password',
            placeholder: 'Create Password',
            autocomplete: 'password'
        }
        , {
            label: 'Confirm Password',
            name: 'confirm_password',
            type: 'password',
            placeholder: 'Confirm Password',
            autocomplete: 'password'
        }
    ]



    const [usersignupdata, setusersignupdata] = useState({})

    const usersignupchange = (e) => {
        setusersignupdata({ ...usersignupdata, [e.target.name]: e.target.value })
    }
    console.log(usersignupdata);
    

    const usersignupcheck = async(e) => {
        e.preventDefault()

        if(usersignupdata.password==usersignupdata.confirm_password){
        try{
        const response=await axios.post("http://127.0.0.1:8000/create_user",usersignupdata)
        console.log(response);
        
        if(response.data.message=='User created successfully'){
            alert(response.data.message)
            navigate('/')
        }
        else{
            alert('signup failed')
        }
        }
        catch(error){
            console.log(error)
        }
    }
    else{
        alert("password must be same")
    }
    }

    const navigate=useNavigate()

    return (
        <div className='user-signup-main'>
            <div className="user-signup-left-side">
                <img className='user-signup-img' src={user} alt="" />
            </div>
            <form className="user-signup-right-side" onSubmit={usersignupcheck} method='post'>
                <div className="user-signup-card">
                    <div className="user-signup-inner-card-container">
                        <div className="user-signup-head-text">
                            Signup
                        </div>
                        {signupuserdata.map((value) => (
                            <div key={value.name} className='user-signup-input-div'>
                                <label className='user-signup-label-text' htmlFor="">{value.label} :</label>
                                <input className='user-signup-input' onChange={usersignupchange} name={value.name} placeholder={value.placeholder} type={value.type} autoComplete={value.autocomplete} required />
                            </div>
                        ))}
                        <button className='user-signup-btn' onClick={usersignupcheck}>Signup</button>
                        <button className="back-btn" onClick={()=>navigate("/")}>
                            <span>←</span> Back
                        </button>
                    </div>
                </div>
            </form>
        </div>
    )
}
