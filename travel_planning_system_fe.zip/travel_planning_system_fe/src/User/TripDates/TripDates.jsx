import React, { useState } from "react";
import "./Tripdates.css"
import { useLocation, useNavigate } from "react-router-dom";
export default function TripDates() {
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");
    const [days, setDays] = useState(0);

    const calculateDays = (start, end) => {
        if (!start || !end) {
            setDays(0);
            return;
        }

        const s = new Date(start);
        const e = new Date(end);

        const diff = e - s;
        const totalDays = diff / (1000 * 60 * 60 * 24);

        if (totalDays >= 0) setDays(totalDays + 1);
        else setDays(0);
    };

    const handleStartDate = (value) => {
        setStartDate(value);
        calculateDays(value, endDate);
    };

    const handleEndDate = (value) => {
        setEndDate(value);
        calculateDays(startDate, value);
    };

    const navigate = useNavigate()
    const loc = useLocation()
    console.log(loc.state);

    return (
        <div className="ta-trip-container">
            <div className="ta-trip-card">

                <div className="ta-back">← Back</div>

                <h2 className="ta-title">Select your trip dates</h2>

                <div className="ta-date-section">

                    <div className="ta-date-box">
                        <label>Start Date</label>
                        <input
                            type="date"
                            value={startDate}
                            onChange={(e) => handleStartDate(e.target.value)}
                        />
                    </div>

                    <div className="ta-date-box">
                        <label>End Date</label>
                        <input
                            type="date"
                            value={endDate}
                            onChange={(e) => handleEndDate(e.target.value)}
                        />
                    </div>

                </div>

                <div className="ta-days-preview">
                    Total Days: {days}
                </div>

                <button
                    className="ta-next-btn"
                    disabled={days === 0}
                    onClick={() => navigate("/travelmode", {
                        state: {
                            mood_text: loc.state.mood_text,
                            members: loc.state.members,
                            people_type: loc.state.people_type,
                            budget: loc.state.budget,
                            date:startDate
                        }
                    })} >
                    Next
                </button>

            </div>
        </div>
    );
}