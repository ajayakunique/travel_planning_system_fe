import { useEffect, useState } from "react";
import "./TravelWith.css";
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import FamilyRestroomIcon from '@mui/icons-material/FamilyRestroom';
import PeopleOutlineIcon from '@mui/icons-material/PeopleOutline';
import BackButton from "../../Common/BackButton/BackButton";
import { useLocation, useNavigate } from "react-router-dom";

function TravelWith() {
  const [selected, setSelected] = useState("");
  const loc = useLocation()
  console.log(loc.state);

 const members = loc.state.members;

const options = [
  ...(members === 1
    ? [{
        name: "Solo",
        icon: <PermIdentityIcon sx={{ fontSize: "30px" }} />,
      }]
    : []),

  {
    name: "Couple",
    icon: <FavoriteBorderIcon sx={{ fontSize: "30px" }} />,
  },
  {
    name: "Family",
    icon: <FamilyRestroomIcon sx={{ fontSize: "30px" }} />,
  },
  {
    name: "Friends",
    icon: <PeopleOutlineIcon sx={{ fontSize: "30px" }} />,
  },
];

useEffect(() => {
  if (members === 1) setSelected("Solo");
}, [members]);


  const navigate = useNavigate()

  return (
    <div className="travel-container">
      <div className="card">
        <BackButton onclick={() => navigate('/trippeople')} />
        <h2>Who are you travelling with?</h2>

        <div className="options">
          {options.map((opt) => (
            <div
              key={opt.name}
              className={`option-card ${selected === opt.name ? "active" : ""
                }`}
              onClick={() => setSelected(opt.name)}
            >
              <div className="travel-icon" >{opt.icon}</div>
              <div className="label">{opt.name}</div>
            </div>
          ))}
        </div>

        <button className="next-btn" onClick={() => {
          if (selected == "" || selected == null) {
            alert("select type")
          }
          else {
            navigate('/budget', {
              state:
              {
                members: loc.state.members,
                mood_text: loc.state.mood_text,
                people_type: selected
              }
            })
          }
        }
        }

        >Next</button>

      </div>
    </div>
  );
}

export default TravelWith;
