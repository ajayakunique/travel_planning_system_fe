import React, { useState } from 'react'
import "./UserResetPassword.css"
import { useLocation, useNavigate } from 'react-router-dom'
import user from "../../assets/user.svg"
import axios from 'axios'

export default function UserResetPassword() {

    const loc = useLocation()
    const navigate = useNavigate()


    const signupresetdata = [
        {
            label: 'New Password',
            name: 'new_password',
            type: 'password',
            placeholder: 'New Password'
        },
        {
            label: 'Confirm Password',
            name: 'confirm_password',
            type: 'password',
            placeholder: 'Confirm Password'
        }
    ]

    const [userresetdata, setuserresetdata] = useState({})

    console.log(userresetdata);


    const userresetchange = (e) => {
        setuserresetdata({ ...userresetdata, [e.target.name]: e.target.value })
    }

    const userresetcheck = async (e) => {
        e.preventDefault()

        if (userresetdata.new_password === userresetdata.confirm_password) {
            try {
                const response = await axios.post("http://127.0.0.1:8000/reset_password", {
                    password:userresetdata.confirm_password,
                    email:loc.state.email
                })
                console.log(response);

                if (response.data.message == "Reset password successfully") {
                    navigate("/userlogin")
                }
            }
            catch (error) {
                console.log(error)
            }
        }
        else{
            alert("Password must be match")
        }

    }


    return (
        <div className='user-reset-main'>
            <div className="user-reset-left-side">
                <img className='user-reset-img' src={user} alt="" />
            </div>
            <form className="user-reset-right-side" onSubmit={userresetcheck} method='post'>
                <div className="user-reset-card">
                    <div className="user-reset-inner-card-container">
                        <div className="user-reset-head-text">
                            Reset Password
                        </div>
                        {signupresetdata.map((value) => (
                            <div key={value.name} className='user-reset-input-div'>
                                <label className='user-reset-label-text' htmlFor="">{value.label} :</label>
                                <input className='user-reset-input' onChange={userresetchange} name={value.name} placeholder={value.placeholder} type={value.type} autoComplete={value.autocomplete} required />
                            </div>
                        ))}
                        <button className='user-reset-btn' onClick={userresetcheck}>Reset Password</button>
                    </div>
                </div>
            </form>
        </div>
    )
}