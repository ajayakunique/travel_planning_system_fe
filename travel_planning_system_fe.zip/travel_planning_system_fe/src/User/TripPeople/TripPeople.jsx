import { useState } from "react";
import "./TripPeople.css";
import BackButton from "../../Common/BackButton/BackButton";
import { useLocation, useNavigate } from "react-router-dom";

function TripPeople() {
  const [count, setCount] = useState(1);
  const increase = () => setCount(count + 1);
  const decrease = () => count > 1 && setCount(count - 1);
  const loc = useLocation()
  console.log(loc.state)
  const navigate = useNavigate()
  const HandleClick = () => {
    navigate('/travelwith', {
      state:
      {
        mood_text: loc.state,
        members: count
      }
    })
  }
  return (
    <div className="people-container">
      <div className="people-card">
        <BackButton onclick={() => navigate('/triphome')} />
        <h2>How many people are travelling?</h2>

        <div className="counter">
          <button className="circle-btn" onClick={decrease}>−</button>

          <div className="count">{count}</div>

          <button className="circle-btn" onClick={increase}>+</button>
        </div>

        <button className="next-btn" onClick={HandleClick}>Next</button>
      </div>
    </div>
  );
}

export default TripPeople;
